'''
单元测试框架 unittest
1. 四大核心概念
TestCase:测试用例
    --测试用例以类的形式去定义，并且一定要继承unittes
    --测试用例方法：用例类里面每一个以test开头的方法，就是一条测试用例
TestSuite:测试套件，测试用例集合

TestRunner:测试运行程序
用例执行的顺序：
1.模块按照的ASCII排序
2.类名按照的ASCII排序
3.方法名按照的ASCII排序
fixture:测试夹具(测试的前置后置条件处理)
四个方法：
    def setup(self):
        #每条测试用例执行之前都会调用该方法，有多少用例执行多少次
        pass
    def tearDown(self):
        #每条测试用例执行之后都会调用该方法，有多少用例执行多少次
        pass
    @classmethod
    def setUpClass(cls):
        #测试类里面的测试用例执行之前都会调用该方法，只会执行一次
        print("-------------setUpClass--------")
    @classmethod
    def tearDownClass(cls):
        #测试类里面的测试用例执行之后都会调用该方法，只会执行一次
        print("-------------tearDownClass--------")

'''
#例子1
import unittest
from login import login_check
class TestLogin(unittest.TestCase):
    def test_login_pass(self):
       # 第一步：准备测试数据，用例的输入参数
       data = {'username':'python31','password':'lemonban'}
       # 预期结果
       expected = {'code':0,'msg':'登陆成功'}
       # 第二步：调用被测的功能函数(请求接口)，传入参数
       res = login_check(**data)
       #第三步：比对预期结果和实际结果（断言）
       self.assertEqual(expected,res)
    def test_login_pwd_error(self):
        data = {'username':'python31','password':'lemonban12'}
        #预期结果
        expected = {'code':1,'msg':'登陆失败'}
        #第二步：调用被测的功能函数(请求接口)，传入参数
        res = login_check(**data)
        #第三步：比对预期结果和实际结果（断
        self.assertEqual(expected,res)
    def test_login_pwd_is_None(self):
        #密码为空
        data = {'username':'python31','password':''}
        expected = {'code':1,'msg':'所有参数不能为空'}
        res = login_check(**data)
        self.assertEqual(expected,res)

    def test_login_account_is_None(self):
        #密码为空
        data = {'username':'','password':'lemonban'}
        expected = {'code':1,'msg':'所有参数不能为空'}
        res = login_check(**data)
        self.assertEqual(expected,res)
#3.测试用例的运行
#第一步：创建一个测试套件
suite = unittest.TestSuite()
#第二步：将测试用例添加到测试套件中
#2.1 创建加载器
loader = unittest.TestLoader()
#2.2 加载用例到套件
# 第一种：通过测试用例类去加载
suite.addTest(loader.loadTestsFromTestCase(TestLogin))
'''
# 第二种：通过测试用例模块去加载
suite.addTest(loader.loadTestsFromModule(test_login))
# 第三种：通过指定文件所在文件路径去加载(用例文件要以test开头)
suite.addTest(loader.discover(r"/Users/zhangcaiyan/Desktop/Lemon_python/unittest_13/testcase"))
用例加载的过程：
1.先找指定路径中test开头的python文件，
2.再找test开头文件中继承unitest.TestCase用例类
3.再去找用例类中以test开头的方法
'''
#第三步：执行测试用例
from unittestreport import TestRunner,HTMLTestRunner
#方式一
runner = TestRunner(suite,filename="reportss.html",title='caiyan测试报告',tester='caiyan',desc='caiyan执行的测试')
runner.run()
#方式二
'''
runner = unittest.TextTestRunner()
runner.run(suite)
#方式三 生产HTMLtestRunnerNew风格的报告
from unittestreport import HTMLTestRunner
runner = HTMLTestRunner(stream = open('cathy.html','wb'))
runner.run(suite)
'''



