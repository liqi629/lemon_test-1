import unittest
from register import register
class TestRegister(unittest.TestCase):
    def setup(self):
        #每条测试用例执行之前都会调用该方法
        print("用例执行前")
    def test_register_pass(self):
        username = 'zhangcaiyan'
        password1 = '12345678'
        password2 = '12345678'
        expected = {"code":1,"msg":"注册成功"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_username_is_None(self):
        username = ''
        password1 = '12345678'
        password2 = '12345678'
        expected = {"code":0,"msg":"所有参数不能为空"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_password_is_None(self):
        username = 'zhangcaiyan'
        password1 = ''
        password2 = ''
        expected = {"code":0,"msg":"所有参数不能为空"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_all_is_None(self):
        username = ''
        password1 = ''
        password2 = ''
        expected = {"code":0,"msg":"所有参数不能为空"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_has_registed(self):
        username = 'python31'
        password1 = '123456'
        password2 = '123456'
        expected = {'code':0,'msg':"该账户已存在"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_username_less6(self):
        username = 'cathy'
        password1 = '123456'
        password2 = '123456'
        expected = {'code':0,'msg':"账号和密码必须在6-18位之间"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_username_more18(self):
        username = 'aaaaabbbbbcccccddddd'
        password1 = '123456'
        password2 = '123456'
        expected = {'code':0,'msg':"账号和密码必须在6-18位之间"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_password_less6(self):
        username = 'cathyy'
        password1 = '12345'
        password2 = '12345'
        expected = {'code':0,'msg':"账号和密码必须在6-18位之间"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_password_more18(self):
        username = 'cathyy'
        password1 = '12345678901234567890'
        password2 = '12345678901234567890'
        expected = {'code':0,'msg':"账号和密码必须在6-18位之间"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_password_not_same(self):
        username = 'cathyy'
        password1 = '123456'
        password2 = '12345'
        expected = {'code':0,'msg':"两次密码不一致"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_mix(self):
        username = 'cathy'
        password1 = ''
        password2 = ''
        expected = {'code':0,'msg':"账号和密码必须在6-18位之间,所有参数不能为空"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)
    def test_register_mix2(self):
        username = ''
        password1 = '12345'
        password2 = '12345'
        expected = {'code':0,'msg':"账号和密码必须在6-18位之间,所有参数不能为空"}
        res = register(username,password1,password2)
        self.assertEqual(res,expected)  
    
    def tearDown(self):
        #每条测试用例执行之后都会调用该方法
        print("用例执行完毕")
    @classmethod
    def setUpClass(cls):
        #测试类里面的测试用例执行之前都会调用该方法
        print("-------------setUpClass--------")
    @classmethod
    def tearDownClass(cls):
        #测试类里面的测试用例执行之后都会调用该方法
        print("-------------tearDownClass--------")



