import unittest
from login import login_check
class TestLogin(unittest.TestCase):
    def test_login_pass(self):
       #第一步：准备测试数据，用例的输入参数
       data = {'username':'python31','password':'lemonban'}
       #预期结果
       expected = {'code':0,'msg':'登陆成功'}
       #第二步：调用被测的功能函数(请求接口)，传入参数
       res = login_check(**data)
       # 第三步：比对预期结果和实际结果（断言）
       self.assertEqual(expected,res)
    def test_login_pwd_error(self):
        data = {'username':'python31','password':'lemonban12'}
        #预期结果
        expected = {'code':1,'msg':'登陆失败'}
        #第二步：调用被测的功能函数(请求接口)，传入参数
        res = login_check(**data)
        #第三步：比对预期结果和实际结果（断
        self.assertEqual(expected,res)
    def test_login_pwd_is_None(self):
        #密码为空
        data = {'username':'python31','password':''}
        expected = {'code':1,'msg':'所有参数不能为空'}
        res = login_check(**data)
        self.assertEqual(expected,res)

    def test_login_account_is_None(self):
        #密码为空
        data = {'username':'','password':'lemonban'}
        expected = {'code':1,'msg':'所有参数不能为空'}
        res = login_check(**data)
        self.assertEqual(expected,res)
    def setup(self):
        #每条测试用例执行之前都会调用该方法
        pass
    def tearDown(self):
        #每条测试用例执行之后都会调用该方法
        pass
    @classmethod
    def setUpClass(cls):
        #测试类里面的测试用例执行之前都会调用该方法
        print("-------------setUpClass--------")
    @classmethod
    def tearDownClass(cls):
        #测试类里面的测试用例执行之后都会调用该方法
        print("-------------tearDownClass--------")