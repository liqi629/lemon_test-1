import unittest
from testcase.test_register import TestRegister
#第一步：创建一个测试套件
suite = unittest.TestSuite()
#第二步：将测试用例添加到测试套件中
#2.1 创建加载器
loader = unittest.TestLoader()
#2.2 加载用例到套件
# 第一种：通过测试用例类去加载
suite.addTest(loader.loadTestsFromTestCase(TestRegister))
'''
# 第二种：通过测试用例模块去加载
suite.addTest(loader.loadTestsFromModule(test_login))
# 第三种：通过指定文件所在文件路径去加载(用例文件要以test开头)
suite.addTest(loader.discover(r"/Users/zhangcaiyan/Desktop/Lemon_python/unittest_13/testcase"))

用例加载的过程：
1.先找指定路径中test开头的python文件，
2.再找test开头文件中继承unitest.TestCase用例类
3.再去找用例类中以test开头的方法
'''
# suite = unittest.defaultTestLoader.discover(r"/Users/zhangcaiyan/Desktop/Lemon_python/py_13/testcase")

#第三步：执行测试用例
from unittestreport import TestRunner,HTMLTestRunner
#方式一
runner = TestRunner(suite,filename="reportss.html",title='caiyan测试报告',tester='caiyan',desc='caiyan执行的测试')
runner.run()
#方式二
'''
runner = unittest.TextTestRunner()
runner.run(suite)

#方式三 生产HTMLtestRunnerNew风格的报告

from unittestreport import HTMLTestRunner
runner = HTMLTestRunner(stream = open('cathy.html','wb'))
runner.run(suite)
'''