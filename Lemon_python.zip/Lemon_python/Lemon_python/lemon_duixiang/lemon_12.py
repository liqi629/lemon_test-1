class BaseClass(object):

    def __init__(self,name):
        self.name = name 

class My_class(BaseClass):
    def __init__(self,name,age):
    #调用父类的方法
        #BaseClass.__init__(self,name)
        #super().__init__(name)
        #继承类时一定要使用super(子类名，self).__init__(子类需要继承父类的参数)去初始化父类，否则继承的父类将没有name
        #super(子类名，self)将返回当前类继承的父类，然后调用__init__方法，此时__init__已经不需要传入self参数，因为在super时已经传入
        super(My_class,self).__init__(name)

    #重写之后扩展的功能代码
        self.age = age
    def func(self):
        pass
m = My_class('cathy',18)
print(m.name)
print(m.age)
列表
class Person(object):
    def __init__(self,*list):
        for attr in list:
            setattr(self,attr,None)
list =['name','age','gender','birth','job']
xiaoming = Peron(*list)
xiaoming.name ='xiaoming'
xiaoming.age = 18
print(xiaoming.age)


字典


class Person(object):
    def __init__(self,**dic):
        for attr,values in dic.items():
            setattr(self,attr,values)
dic ={'name':'cathy','gender':'male','birth':'2017-12-10','job':'student','age':18}
xiaoming = Peron(**dic)
print(xiaoming.name)
print(xiaoming.age)
