#作业1，通过继承定义三个类，Phonev1,PhoneV2,PhoneV3

class PhoneV1(object):
    attr = '移动电话'
    def __init__(self,name,price,year):
        self.name = name
        self.price = price
        self.year = year
    def call(self):
        print(f"{self.name},可以打电话")
class PhoneV2(PhoneV1):
    def __init__(self, name, price, year,pixel):
        super().__init__(name, price, year)
        self.pixel = pixel
    def music(self):
        print(f"{self.name},可以听音乐")
    def send_msg(self):
        print(f"{self.name},可以发消息")
    def photo(self):
        print(f"{self.name},可以拍照") 
class PhoneV3(PhoneV2):
    def __init__(self, name, price, year, pixel,screen):
        super().__init__(name, price, year, pixel)
        self.screen = screen
    def video(self):
        print(f"{self.name},可以视频")
MyPhone = PhoneV3('iphone6P',3000,'2015','1080P','5.6')
print(MyPhone.price)
print(MyPhone.pixel)
MyPhone.video()
MyPhone.call()

#作业2，有一组数据，如下格式{'case_id':1,'method':'post','url':'/method/login','data':'123','actual':'不通过‘，'expected':'不通过‘}
#定义一个类，请通过setattr将上面的字典的键值对，分别设置为类的属性和属性值

class CaseData:
    def __init__(self,**kw):
        for attr,value in kw.items():
            setattr(CaseData,attr,value)
dic = {'case_id':1,'method':'post','url':'/method/login','data':'123','actual':'不通过','expected':'不通过'}

MyCase = CaseData(**dic)
print(MyCase.method)
print(MyCase.case_id)
print(MyCase.actual)



class CaseData2:
    pass
dic = {'case_id':1,'method':'post','url':'/method/login','data':'123','actual':'不通过','expected':'不通过'}
for k,v in dic.items():
    setattr(CaseData2,k,v)
print(CaseData2.__dict__)