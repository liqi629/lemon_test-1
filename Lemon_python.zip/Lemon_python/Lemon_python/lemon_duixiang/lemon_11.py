'''
#作业1 
类属性:直接定义在类里面的变量(该类事物共有的特征,特征值都是一样的)
实例属性:对象自己的一些属性(和类里面的其他对象的属性值有可能是不一样的)
实例属性的定义:对象.属性名 = 属性值
#作业2
实例方法中的self代表对象本身自己
#作业3
类中__init__方法在实例化对象的时候被调用
#作业4
封装一个学生类,属性身份(学生)
姓名,年龄,性别,英语成绩,数学成绩,语文成绩
方法一.计算总分
方法二.计算三科的平均分
方法三.打印学生的个人信息
'''
class Student:
    id = "学生"
    def __init__(self,name,age,sex,eng,math,chinese):
        self.name = name
        self.age = age
        self.sex = sex
        self.eng = eng
        self.math = math
        self.chinese = chinese
    def sum(self):
        res = self.eng + self.math + self.chinese
        return res
    def average(self):
        sum1 = self.sum()
        avg = sum1 / 3
        return avg

    def out(self):
        print(f"姓名:{self.name},年龄:{self.age},性别:{self.sex},总分:{res},平均分:{avg:.2f}")
print(Student.id)
xiaowang = Student('王三',18,'男',78,87,97)
res = xiaowang.sum()
print(res)
avg = xiaowang.average()
print("平均为{:.2f}".format(avg))
xiaowang.out()
'''
#作业5
封装一个测试用例类
属性:用例编号,Url地址,请求参数,请求方法, 预期结果,实际结果
'''
class TestCase:
    id = '测试用例'
    def __init__(self,caseId,Url,paramer,method,expectresult,actualresult):
        self.caseId = caseId
        self.Url = Url
        self.paramer = paramer
        self.method = method
        self.expectresult = expectresult
        self.actualresult = actualresult
webTest = TestCase('01','https://live-playapi-test.ciftis.org.cn/v1/likes/','321','POST','点赞数327','0')
print(webTest.id)
print(webTest.Url)
print(webTest.paramer)
print(webTest.method)

#作业6扩展
class Boy:
    sex = '男'
    def __init__(self,age,height,education,salary):
        self.age = age
        self.height = height
        self.education = education
        self.salary = salary
        
    def House(self):
        print("名下有房")
    def Car(self):
        print("名下有车")
    def biaozhun(self):
        print(f"年龄:{self.age},身高:{self.height},学历:{self.education},收入:{self.salary}")

Eason = Boy(30,178,'bachelor','40万')
Eason.biaozhun()
Eason.House()
Eason.Car()
        


       