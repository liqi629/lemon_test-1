import ddt
import unittest
from register import register

from Lemon_python.py_14.lemon_14_demo4 import read_data
res = read_data('cases.xlsx','register')
dic ={}
case_data =[]
for i in range(len(res)):
    dic['expected'] = eval(res[i]['expected'])
    dic['data'] = eval(res[i]['data'])
    print(dic)