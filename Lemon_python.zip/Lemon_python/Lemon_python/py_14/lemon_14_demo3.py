import openpyxl

# 第一步：将excel文件加载到一个工作簿对象中
wb = openpyxl.load_workbook("cases.xlsx")
# 第二步：选择文件中的表单
sh = wb["login"]
# 一次性读取表
res = list(sh.rows)
# 获取第一行的单元格
title = []
for i in res[0]:
    title.append(i.value)
cases_data =[]
for item in res[1: ]:
    data =[]
    for c in item:
        data.append(c.value)
    case = dict(zip(title,data))
    cases_data.append(case)
print(cases_data)
