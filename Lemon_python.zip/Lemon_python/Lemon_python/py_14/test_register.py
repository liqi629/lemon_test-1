# 1.用例和数据的分离处理
# ddt:data driver test(数据驱动测试)
import ddt
import unittest
from register import register
from Lemon_python.py_14.lemon_14_demo4 import read_data
res = read_data('cases.xlsx','register')
@ddt.ddt
class RegisterTestCase(unittest.TestCase):
    @ddt.data(*res)
    def test_register(self,case_data):
            excepted = eval(case_data["expected"])
            data = eval(case_data["data"])
            res2 = register(**data)
            self.assertEqual(excepted,res2)







