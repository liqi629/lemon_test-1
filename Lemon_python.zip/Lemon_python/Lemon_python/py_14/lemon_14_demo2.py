#2.python操作Excel
'''
excel操作三大对象：
工作簿：一个excel文件会被加载成为一个工作簿对象workbook
工作表：excel文件每个sheet表达会被加载成一个工作表对象
单元格：工作表中每一个格子就是一个表格对象
'''
import openpyxl
# 将excel文件加载到一个工作簿对象中
workbook= openpyxl.load_workbook('data.xlsx')
# 选中文件中的表单
sheet = workbook['login']
# 读取内容，并打印值
res = sheet.cell(row = 1,column = 1)
print(res.value)

#在往excel写入数据的时候，表格不能是打开的
import openpyxl
wb = openpyxl.load_workbook('data.xlsx')
sh = wb['login']
#往表格中写入数据
sh.cell(row=1,column=1,value='cathy')
#第四步，保存
wb.save('data.xlsx')

import openpyxl

# 第一步：将excel文件加载到一个工作簿对象中
wb = openpyxl.load_workbook("musen.xlsx")
# 第二步：选择文件中的表单
sh = wb["login"]
# 一次性读取表
res = list(sh.rows)
print(res)
for item in res:
    for c in item:
        print(c.value,end = '   ')
    print()