# 1.用例和数据的分离处理
# ddt:data driver test(数据驱动测试)
from Lemon_python.py_15 import myddt
import unittest
from Lemon_python.py_15.register import register
from Lemon_python.py_15.My_excel import Excel

@myddt.ddt
class RegisterTestCase(unittest.TestCase):
    excel = Excel(r'/Users/zhangcaiyan/Desktop/Lemon_python/Lemon_python/py_15/cases.xlsx', 'register')
    res = excel.read_data()
    @myddt.data(*res)
    def test_register(self,case_data):
            case_row = eval(case_data['case_id']) + 1
            excepted = eval(case_data["expected"])
            data = eval(case_data["data"])
            res = register(**data)
            try:
                self.assertEqual(excepted,res)
            except AssertionError as e:
                self.excel.write_data(row=case_row, column=5, value='失败')
                print("用例执行失败")
                raise e
            else:
                self.excel.write_data(row=case_row, column=5, value='通过')








