import unittest
from Lemon_python.py_15 import myddt
from Lemon_python.py_15.login import login_check
from Lemon_python.py_15.My_excel import Excel

@myddt.ddt
class TestLogin(unittest.TestCase):
    excel = Excel(r'/Users/zhangcaiyan/Desktop/Lemon_python/Lemon_python/py_15/cases.xlsx', 'login')
    case = excel.read_data()
    @myddt.data(*case)
    def test_login(self,case_data):
        case_row = eval(case_data['case_id']) + 1
        excepted = eval(case_data["expected"])
        data = eval(case_data["data"])
        res2 = login_check(**data)
        try:
            self.assertEqual(excepted, res2)
        except AssertionError as e:
            self.excel.write_data(row=case_row, column=5, value='失败')
            print('用例执行失败')
            raise e
        else:
            self.excel.write_data(row=case_row, column=5, value='通过')




