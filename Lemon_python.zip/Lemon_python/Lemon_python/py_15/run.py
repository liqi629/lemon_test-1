import unittest
from unittestreport import TestRunner,HTMLTestRunner
#第一步：创建一个测试套件
suite = unittest.TestSuite()
#第二步：将测试用例添加到测试套件中
#2.1 创建加载器
loader = unittest.TestLoader()
#2.2 加载用例到套件
suite.addTest(loader.discover(r"/Users/zhangcaiyan/Desktop/Lemon_python/Lemon_python/py_15/testcase"))
#第三步：执行测试用例
#方式一
runner = TestRunner(suite,filename="report.html",title='caiyan测试报告',tester='caiyan',desc='caiyan执行的测试')
runner.run()

