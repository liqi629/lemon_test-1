#### 一.读取文件

**1.语法：**

open ("文件名“，打开文件的格式，endcoding = 'utf-8")
注意点： 被打开的文件和当前文件在同一路径下，可以直接写文件名，不在同一路径下，写文件完整的路径
**2.三种读取方法：**
read():读取文件中所有的内容
readline():按行读取，每次读取一行的内容
readlines():按行读取，按行把所有的内容读取到列表中,每一行就是列表中的每个元素

```python
例子1:
f = open('test.txt','r',encoding = 'utf-8')
#读取文件的所有的内容
content = f.read()
contents = f.readlines()
c7 = f.readlines()[6]
print(c7)
print(content)
#一定要关闭文件
f.close()
```

**3.打开文件的模式**
r: 只读模式（read)，如果文件不存在，则会报错（提示文件找不到）
w: 写入模式(write)(覆盖写入，把文件原有的内容清除，如果文件不存在，则会自动创建）
a: 写入模式（append),（追加写入，在文件原来的内容尾部写入新的内容，文件不存在，则会自动创建）
#通常用来操作非文本格式的文件（比如图片）
rb:只读模式，以二进制的模式打开，
wb:写入模式，以二进制的模式写入，
ab: 写入模式，以二进制的模式写入，

#### 二. 文件写入

```python
例子2:图片的复制
#打开文件
f1 = open('a.gif','rb')
f2 = open('copy.gif','wb')
#读取文件，写入文件
content = f1.read()
f2.write(content)
f1.close()
f2.close()
```

#### 三. 上下文管理器 with 

注意点：通过with打开文件，操作完不需要关闭文件

```python
例子3:
with open('a.gif','rb') as f:
    content = f.read()
with open('copy.gif','wb') as f2: 
    f2.write(content)
```

#### 四.模块和包

**1. 定义**
模块：在python中只要是.py结尾的文件都可以称之为模块
包：包含__init__.py的文件的文件夹就可以称之为一个python包

**2.模块和包的导入**
#方式一
import 模块名
#方式二
from 包名（如果存在多级嵌套的情况） import 模块名
需要一级一级的往下走
#方式三
导入模块中的某个函数或者变量
from 模块名 import 函数名/变量
from 包名.模块名 import 变量名/函数
#相对于项目路径，一级一级往下导入 
from 包名 import 模块名
from XXX import XXX  as 别名

__init__.py 有什么作用:pyton 包的标识

下面的这个条件，只有在直接运行该文件的时候才会成立（该文件作为启动文件）
if __name__ == '__main__'
__name__:它是python中的一个魔法变量，（值不是固定的）
当文件作为程序的入口文件（作为启动文件），它的值为__main__
其他情况，该模块作为被其他模块导入的时候，它的值作为模块名

关于python中包导入搜索路径