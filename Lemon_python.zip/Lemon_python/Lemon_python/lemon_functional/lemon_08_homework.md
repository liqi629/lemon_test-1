> **\#作业1: 请封装一个函数，按要求实现数据的格式转换**
>
> **\#传入参数：data = ["{'a':11,'b':2}","[11,22,33,44]"]**
>
> **\#返回结果：res = [{'a':11,'b':2},[11,22,33,44]]**
>
> **\#通过代码将传入参数转换为返回结果所需数据，然后返回**

```python
print("*********第一题**********")
res = []
def func(li):
	for i in li:
		res.append(eval(i))
	print(res)
data = ["{'a':11,'b':2}","[11,22,33,44]"]
func(data)   
```

***************第一题运行结果*****************
**[{'a': 11, 'b': 2}, [11, 22, 33, 44]]**

> **\#作业2:请封装一个函数。完成如下数据格式转换**
>
> **\#传入参数：**
>
> **cases = [**
>
> ​    **['case_id','case_title','url','data','expected'],**
>
> ​    **[1,'用例1','www.baidu.com','001','ok'],**
>
> ​    **[2,'用例2','www.baidu.com','002','ok'],**
>
> ​    **[3,'用例3','www.baidu.com','002','ok'],**
>
> ​    **[4,'用例4','www.baidu.com','002','ok'],**
>
> ​    **[5,'用例5','www.baidu.com','002','ok'],**
>
> **]**
>
> **\#返回结果：**
>
> **cases02 = [**
>
> ​    **{'case_id':1,'case_title':'用例1','url':'www.baidu.com','data':'001','expected':'ok'},**
>
> ​    **{'case_id':2,'case_title':'用例2','url':'www.baidu.com','data':'002','expected':'ok'},**
>
> ​    **{'case_id':3,'case_title':'用例3','url':'www.baidu.com','data':'002','expected':'ok'},**
>
> ​    **{'case_id':4,'case_title':'用例4','url':'www.baidu.com','data':'002','expected':'ok'},**
>
> ​    **{'case_id':5,'case_title':'用例5','url':'www.baidu.com','data':'002','expected':'ok'}**
>
> **]**

```python
print("*********第二题结果*****")
cases02 = []
def fun(li):
	for item in li[1:]:
    dic = dict(zip(li[0],item))
    cases02.append(dic)
  print(cases02)
cases = [
  ['case_id','case_title','url','data','expected'],
  [1,'用例1','www.baidu.com','001','ok'],
  [2,'用例2','www.baidu.com','002','ok'],
  [3,'用例3','www.baidu.com','002','ok'],
  [4,'用例4','www.baidu.com','002','ok'],
  [5,'用例5','www.baidu.com','002','ok'],
]
fun(cases)
```

***************第二题运行结果*****************

**[{'case_id': 1, 'case_title': '用例1', 'url': 'www.baidu.com', 'data': '001', 'expected': 'ok'},** 

**{'case_id': 2, 'case_title': '用例2', 'url': 'www.baidu.com', 'data': '002', 'expected': 'ok'},** 

**{'case_id': 3, 'case_title': '用例3', 'url': 'www.baidu.com', 'data': '002', 'expected': 'ok'},**

 **{'case_id': 4, 'case_title': '用例4', 'url': 'www.baidu.com', 'data': '002', 'expected': 'ok'},**

 **{'case_id': 5, 'case_title': '用例5', 'url': 'www.baidu.com', 'data': '002', 'expected': 'ok'}]**

**#作业3：简答题****

1.全局变量：在python中直接定义在模块（py文件中的变量）叫做全局变量,在该文件中任意位置都能使用

2.局部变量：定义在函数中的变量叫做局部变量，只能在该函数内部使用

3.函数内部，可以用global来声明全局变量，要先声明，然后在赋值

用法：global num

​           Num = 200

​          

