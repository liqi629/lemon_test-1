print("**********************************第一题**********************************")
with open('txt_for_hk9.txt', 'r', encoding='utf-8') as f1:
    list_1 = f1.readlines()
for i1 in range(len(list_1)):
    list_1[i1] = list_1[i1].replace('\n','')
dic1 = {}
for key1,value1 in enumerate(list_1):
    dic1[F'data{key1}'] = value1
print(dic1)
print("**********************************第二题**********************************")
with open('case_for_hk9.txt','r',encoding='utf-8') as f2:
    list_2 = f2.readlines()
list2_res = []
for i2 in range(len(list_2)):
    list_2[i2] = list_2[i2].replace('\n','')
    list_temp = list_2[i2].split(',')
    dic2_temp = {}
    for j2 in range(len(list_temp)):
        list_temp[j2] = list_temp[j2].split(':')
        dic2_temp[list_temp[j2][0]] = list_temp[j2][1]
    list2_res.append(dic2_temp)
print(list2_res)
dic2 = {}
for key2,value2 in enumerate(list2_res):
    dic2[F'data{key2+1}'] = value2
print(dic2)
print("**********************************第三题**********************************")
with open("users_for_hk9.txt","r",encoding="utf-8") as f3:
    list_3 = f3.readlines()
for i3 in range(len(list_3)):
    list_3[i3] = eval(list_3[i3].replace('\n',''))
id = input("请输入账号：")
pwd = input("请输入密码：")
pwd2 = input("请再次确认密码：")
for u in list_3:
    if id == u["uid"]:
        print("该账号已经被注册！")
        break
else:
    if pwd == pwd2:
        list_3.append({'uid':id,"pwd":pwd})
        with open("users_for_hk9.txt", "a", encoding="utf-8") as f3:
            f3.write(str(list_3[-1]) + '\n')
        print("注册成功！")
    else:
        print("两次输入的密码不一致！")
print("**********************************第四题**********************************")
"""
在python中读取文件
open：(文件名（含路径）,打开文件的模式,encoding = "utf-8")
with：通过with打开文件，操作完之后会自动关闭文件
    with open("a","r") as f:
        content = f.read()

打开文件的模式：
    r：只读模式（read），如果文件不存在会报错
    w：写入模式（write），覆盖写入（清除文件中原有内容），如果文件不存在会自动创建
    a：写入模式（append），追加写入（在文件中原有内容后写入新内容），如果文件不存在会自动创建

    通常用来读写非文本格式的文件
    rb：只读模式（read），以二进制的模式打开文件，如果文件不存在会报错
    wb：写入模式（write），以二进制的模式打开文件，覆盖写入（清除文件中原有内容），如果文件不存在会自动创建
    ab：写入模式（append），以二进制的模式打开文件，追加写入（在文件中原有内容后写入新内容），如果文件不存在会自动创建

注意：
    被打开的文件和当前文件在同一路径下，可以写文件名
    被打开的文件和当前文件不在同一路径下，可以写文件完整路径

read：读取文件中所有的内容
readline：每次读取一行内容
readlines：按行把所有内容读取到一个列表中，每一行内容是列表中的一个元素
"""

"""
模块和包导入：
    模块：在python中只要是.py结尾的文件都可以称为模块
    包：包含一个__init__.py文件的文件夹称为包

__init__.py的作用：
    1、是python包的标识
    2、可以在文件内定义包级别的函数、变量

import 模块名
from 包名 import 模块名 —— 如果存在多级嵌套的情况，需要一级一级往下找
    from 包名 import 模块名 as 别名 —— 取了别名后，原模块名在该文件中就无法使用了

导入模块中的某个函数或变量：
    from 模块名 import 变量名/函数名
    from 

if __name__ == "__main__": —— 只有在直接运行该文件时才会执行
    __name__是python中的一个魔法变量（值不是固定的）
        当文件作为程序的入口文件（启动文件）时，值为__main__
        当文件被其他模块导入时，值为文件名
"""
# f = open("test.txt","w",encoding = "utf-8")
# 读取文件
# content = f.read()
# print(content)
# for i in range(5):
#     print(f.readline())
# c7 = f.readlines()[6]
# print(c7)
# f.close()

# 文件的复制
# f1 = open(r"C:\Users\11064\Pictures\Saved Pictures\123.jpg","rb")
# f2 = open("321.jpg","wb")
# content123 = f1.read()
# content321 = f2.write(content123)
# f1.close()
# f2.close()
