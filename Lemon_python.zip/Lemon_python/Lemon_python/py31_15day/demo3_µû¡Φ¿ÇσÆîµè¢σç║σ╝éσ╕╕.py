"""
============================
Author:柠檬班-木森
Time:2020/8/1   11:01
E-mail:3247119728@qq.com
Company:湖南零檬信息技术有限公司
============================
"""

"""
关键字：
断言：assert
抛出异常：raise:
    raise:主动引发异常
"""
#
# print('---------1--------')
# res = "python1"
# exp = "python"
# try:
#     assert res ==exp
# except AssertionError as e:
#     print("断言不通过")
#     raise e
# else:
#     print("通过")

# print('---------2--------')


# raise TypeError("musen 主动报错的异常")