#拆包
def read_list(*args):
    for i in args:
        print(i)
    return i
li = [11,22,33,44,55]
res = read_list(*li)
tup = (66,77,88,99)
res2 = read_list(*tup)
print(res2)

def read_dic(**kwargs):
    for k,v in kwargs.items():
        print(k,v)
    return k,v
dic = {'name':'cathy','age':18}
(a,b) = read_dic(**dic)
print(a)
print(b)